package com.javaproject.teachers.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class AuditFilter implements Filter {

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		String IP=req.getRemoteHost();
		System.out.println("IP Address of Incoming Request is ::" +IP);
		req.setAttribute("Host", IP);
		chain.doFilter(req, resp);
		System.out.println(resp.getContentType());

	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("AuditFilter Initialized");
	}
	
}
