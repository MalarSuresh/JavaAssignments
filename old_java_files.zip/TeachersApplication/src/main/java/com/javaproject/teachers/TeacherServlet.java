package com.javaproject.teachers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.javaproject.teachers.bl.TeacherBO;
import com.javaproject.teachers.dto.Teacher;

@WebServlet(description = "Teacher Servlet", urlPatterns = { "/teacher" })
public class TeacherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private TeacherBO teacherBO;   
	public void init(ServletConfig config) throws ServletException {
	teacherBO=new TeacherBO();
	
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession(false);
		if(session!=null) {
		session.invalidate();
		}
		RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
		rd.forward(req, resp);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Teacher teacher =new Teacher();
		 teacher.setTeacherName(request.getParameter(Teacher.TEACHER_NAME));
		 teacher.setTeacherSkills(request.getParameter(Teacher.TEACHER_SKILLS));
		 teacher.setYrsOfExp(Integer.parseInt(request.getParameter(Teacher.YRS_OF_EXP)));
		 teacher.setLocation(request.getParameter(Teacher.LOCATION));
		
		 String message=teacherBO.executeSaveTeacher(teacher);
		 PrintWriter out=response.getWriter();
		 out.print(message);
	}

}
