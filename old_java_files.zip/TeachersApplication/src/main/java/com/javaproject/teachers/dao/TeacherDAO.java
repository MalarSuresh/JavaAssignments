package com.javaproject.teachers.dao;

import java.sql.Connection;

import com.javaproject.teachers.dto.Teacher;

public class TeacherDAO {

	public int createTeacher(Teacher teacher) {
		Connection conn=ConnectionUtil.getConnection();
		System.out.println("Received Connection from JNDI" +conn);
		return 1;
	}

}
