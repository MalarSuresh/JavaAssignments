package com.javaproject.teachers.Listener;

import java.util.Enumeration;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class LifeCycleListener implements ServletRequestListener, HttpSessionListener, ServletContextListener {
	@Override
	public void requestInitialized(ServletRequestEvent sre) {
	String UniqueID="TCHR"+System.currentTimeMillis();
	sre.getServletRequest().setAttribute("AppCd","TCHR");
	sre.getServletRequest().setAttribute("UnqId",UniqueID);

	}
	
	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		System.out.println("Request Destroyed"+sre.getServletRequest().getAttribute("UnqId"));
	}
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("ServletContext:: Context Initialized");
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("ServletContext:: Context Destroyed");

	}

	@Override
	public void sessionCreated(HttpSessionEvent se) {
		System.out.println("HttpSessionEvent ::session created"+se.getSession().getId());
		se.getSession().setMaxInactiveInterval(600);
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		System.out.println("HttpSessionEvent ::session Destroyed");
		Enumeration<String> attrs=se.getSession().getAttributeNames();
		String AttrName=null;
		while(attrs.hasMoreElements()) {
			AttrName=attrs.nextElement();
			System.out.println("Attr Name "+AttrName+" value "+se.getSession().getAttribute(AttrName));
			
		}
	}
}
