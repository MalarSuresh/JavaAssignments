package com.javaproject.teachers.dto;

public class Teacher {
	public Teacher(){
	
	}
	private String teacherName;
	private String teacherSkills;
	private int yrsOfExp;
	private String location;
	
	public static final String TEACHER_NAME="teacherName";
	public static final String TEACHER_SKILLS="teacherSkills";
	public static final String YRS_OF_EXP="yrsOfExp";
	public static final String LOCATION="location";
			
	@Override
	public String toString() {
		return "Teacher [teacherName=" + teacherName + ", teacherSkills=" + teacherSkills + ", yrsOfExp=" + yrsOfExp
				+ ", location=" + location + "]";
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getTeacherSkills() {
		return teacherSkills;
	}
	public void setTeacherSkills(String teacherSkills) {
		this.teacherSkills = teacherSkills;
	}
	public int getYrsOfExp() {
		return yrsOfExp;
	}
	public void setYrsOfExp(int yrsOfExp) {
		this.yrsOfExp = yrsOfExp;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
}
