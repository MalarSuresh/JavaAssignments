package com.javaproject.teachers.dto;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

public class User implements HttpSessionBindingListener{
	

	public User() {
		
	}
	public static final String USERID_KEY="userId";
	public static final String PASSWORD_KEY="password";
	
	private String userId;
	private String password;
	private boolean isAuthenticated;
	private String message;
	
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", password=" + password + ", isAuthenticated=" + isAuthenticated
				+ ", message=" + message + "]";
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isAuthenticated() {
		return isAuthenticated;
	}
	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public void valueBound(HttpSessionBindingEvent event) {
	System.out.println("User is going inside Session");
	}
	@Override
	public void valueUnbound(HttpSessionBindingEvent event) {
		System.out.println("User is going outside Session");

	}
}
