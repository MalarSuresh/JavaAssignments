package com.javaproject.teachers.bl;

import com.javaproject.teachers.dao.TeacherDAO;
import com.javaproject.teachers.dto.Teacher;

public class TeacherBO {
	
	private TeacherDAO teacherDAO=null;
	
	public TeacherBO() {
		teacherDAO=new TeacherDAO();
	}
	 public String executeSaveTeacher(Teacher teacher) {
		String message="";
		 int num=teacherDAO.createTeacher(teacher);
		if (num==1) {
			message="Teacher data saved successfully";
		}
		return message;
	 }
}
