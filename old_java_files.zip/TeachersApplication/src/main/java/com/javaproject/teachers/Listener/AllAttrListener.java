package com.javaproject.teachers.Listener;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

/**
 * Application Lifecycle Listener implementation class AllAttrListener
 *
 */
@WebListener
public class AllAttrListener implements HttpSessionAttributeListener, ServletContextAttributeListener, ServletRequestAttributeListener {

    public void attributeAdded(ServletContextAttributeEvent scae)  { 
        System.out.println("AttrAdded Name - "+scae.getName()+ " value- "+scae.getValue());
    }

	/**
     * @see ServletContextAttributeListener#attributeRemoved(ServletContextAttributeEvent)
     */
    public void attributeRemoved(ServletContextAttributeEvent scae)  { 
        System.out.println("AttrRemovedName - "+scae.getName()+ " value- "+scae.getValue());
    }
    /**
     * @see ServletContextAttributeListener#attributeReplaced(ServletContextAttributeEvent)
     */
    public void attributeReplaced(ServletContextAttributeEvent scae)  { 
        System.out.println("AttrReplacedName - "+scae.getName()+ " Old value- "+scae.getValue());
    }

	/**
     * @see ServletRequestAttributeListener#attributeRemoved(ServletRequestAttributeEvent)
     */
    public void attributeRemoved(ServletRequestAttributeEvent srae)  { 
        System.out.println("AttrRemoved Name - "+srae.getName()+ " value- "+srae.getValue());
    }

	/**
     * @see ServletRequestAttributeListener#attributeAdded(ServletRequestAttributeEvent)
     */
    public void attributeAdded(ServletRequestAttributeEvent srae)  { 
        System.out.println("AttrAdded Name - "+srae.getName()+ " value- "+srae.getValue());
    }

	/**
     * @see ServletRequestAttributeListener#attributeReplaced(ServletRequestAttributeEvent)
     */
    public void attributeReplaced(ServletRequestAttributeEvent srae)  { 
        System.out.println("AttrReplacedName - "+srae.getName()+ " Old value- "+srae.getValue());
    }

	/**
     * @see HttpSessionAttributeListener#attributeAdded(HttpSessionBindingEvent)
     */
    public void attributeAdded(HttpSessionBindingEvent se)  { 
    System.out.println("AttrAdded Name - "+se.getName()+ " value- "+se.getValue());
    
    }

	/**
     * @see HttpSessionAttributeListener#attributeRemoved(HttpSessionBindingEvent)
     */
    public void attributeRemoved(HttpSessionBindingEvent se)  { 
        System.out.println("AttrRemoved Name - "+se.getName()+ " value- "+se.getValue());
    }

	/**
     * @see HttpSessionAttributeListener#attributeReplaced(HttpSessionBindingEvent)
     */
    public void attributeReplaced(HttpSessionBindingEvent se)  { 
        System.out.println("AttrReplaced Name - "+se.getName()+ " Old value- "+se.getValue());
    }

	
	
}
