package com.javaproject.teachers.bl;

import com.javaproject.teachers.dto.User;

public class LoginBO {

	public User executeAuth(User user) {
		String matchPass=user.getUserId()+"@123";
		if(user.getPassword().equalsIgnoreCase(matchPass)) {
			user.setAuthenticated(true);
			user.setMessage("Logged In");
		}else {
			user.setAuthenticated(false);
			user.setMessage("Password is not correct");
		}
			
			return user;
	}

}
