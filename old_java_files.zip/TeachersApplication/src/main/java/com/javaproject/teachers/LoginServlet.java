package com.javaproject.teachers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.javaproject.teachers.bl.LoginBO;
import com.javaproject.teachers.dto.User;

public class LoginServlet extends HttpServlet {
	LoginBO loginbo;

	@Override
	public void init() throws ServletException {
		System.out.println("LoginServlet :: init");
		loginbo= new LoginBO();
	} 
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userId=req.getParameter(User.USERID_KEY);
		String password=req.getParameter(User.PASSWORD_KEY);
		User user=new User();
		user.setUserId(userId);
		user.setPassword(password);
		
		user=loginbo.executeAuth(user);
		req.setAttribute("user", user);
		
		RequestDispatcher rd=null;
		
		if(user.isAuthenticated()) {
			HttpSession session=req.getSession();
			session.setAttribute(User.USERID_KEY, user);
			
			rd=req.getRequestDispatcher("teachers.jsp");
			rd.forward(req, resp);
		}
		else {
			rd=req.getRequestDispatcher("index.jsp");
			rd.forward(req, resp);
		}
	}

	@Override
	public void destroy() {
		System.out.println("LoginServlet :: destroy");

	}

	

}
