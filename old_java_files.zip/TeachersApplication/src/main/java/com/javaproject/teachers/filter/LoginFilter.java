package com.javaproject.teachers.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;

import com.javaproject.teachers.dto.User;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter(description = "Prior check before hitting servlet", urlPatterns = { "/Login" })
public class LoginFilter extends HttpFilter implements Filter {
       
    /**
     * @see HttpFilter#HttpFilter()
     */
    public LoginFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	
		String userId=request.getParameter(User.USERID_KEY);
		String password=request.getParameter(User.PASSWORD_KEY);
		if(userId!=null && password!=null && userId.trim().length()>0&& password.trim().length()>0)
		{
		chain.doFilter(request, response);
		}
		PrintWriter out=response.getWriter();
		out.println("UserId and Password is not valid <a href='index.jsp'>Login</a>");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
