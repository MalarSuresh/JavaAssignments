package com.javaproject.teachers.Listener;

import javax.servlet.http.HttpSessionActivationListener;
import javax.servlet.http.HttpSessionEvent;

public class ActivationTest implements HttpSessionActivationListener {
	@Override
	public void sessionWillPassivate(HttpSessionEvent se) {
	System.out.println("Session before transfer " +se.getSession().getId());
	}
	@Override
	public void sessionDidActivate(HttpSessionEvent se) {
		System.out.println("Session after transfer " +se.getSession().getId());
	}

	

}
