package com.riteAid.store;

import java.rmi.RemoteException;

import com.thomas_bayer.blz.*;

public class TestBLZ {
	public static void main(String[] args) {
		BLZServicePortTypeProxy proxy=new BLZServicePortTypeProxy();
		try {
			DetailsType dt=proxy.getBank("37040044");
			System.out.println(dt);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
}
