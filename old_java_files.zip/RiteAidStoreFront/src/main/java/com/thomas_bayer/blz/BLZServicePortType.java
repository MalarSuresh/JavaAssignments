/**
 * BLZServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.thomas_bayer.blz;

public interface BLZServicePortType extends java.rmi.Remote {
    public com.thomas_bayer.blz.DetailsType getBank(java.lang.String blz) throws java.rmi.RemoteException;
}
