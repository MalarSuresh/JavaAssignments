package com.JMSprograms.jms;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;

public class ActiveMQProducer {
	private static String brokenURL="tcp://localhost:61616";
	
	public static void main(String[] args) throws JMSException {
		ActiveMQConnectionFactory cf=new ActiveMQConnectionFactory(brokenURL);
		Connection conn=null;
		
		try {
			conn=cf.createConnection();
			conn.start();
			Session session=conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Destination queue = session.createQueue("JMS.Test.ProducerQueue");
			MessageProducer producer=session.createProducer(queue);
			Message message=session.createTextMessage("My first message");
			producer.send(message);
			System.out.println("Message sent");
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(conn!=null) conn.close();
		}
	
	
	
	}

}
