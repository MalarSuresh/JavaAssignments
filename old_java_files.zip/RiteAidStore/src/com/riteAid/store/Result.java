package com.riteAid.store;

public class Result {
	private String message;
	private boolean valid;
	
	public Result(String message,boolean valid) {
		this.setMessage(message);
		this.setValid(valid);
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	 
}
