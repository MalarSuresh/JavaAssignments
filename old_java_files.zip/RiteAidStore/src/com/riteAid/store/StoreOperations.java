package com.riteAid.store;

public class StoreOperations {
	 
	public Result validateAge(int age) {
		
		Result result= null;
		if(age > 18 && age <121) {
			result=new Result("Age is Valid",true);
		}else {
			result=new Result("Age is Invalid",false);

		}
		return result;
	}
}
