
public class StringEx {
  public static void main(String args[]) {
	  String txt = "Please locate where 'locate' occurs!";
	  System.out.println(txt.indexOf("locate"));
	  String name1="Malar";
	  String name2="Suresh";
	  String changeName="";
	  System.out.println(name1.indexOf("l"));

  }
  
}
