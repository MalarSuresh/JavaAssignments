package com.FirstHibernateProject.Hibernate.dto;

import java.sql.Timestamp;

import jakarta.persistence.*;

@Entity
@Table(name="teacher")
public class Teacher {
	
	@Id @Column(name="TeacherId")
	@GeneratedValue(generator="native")
	private int TeacherId;
	
	@Column(name="FirstName")
	private String FirstName;
	
	@Column(name="LastName")
	private String LastName;
	
	@Column(name="Skills")
	private String Skills;
	
	@Column(name="LastUpdate")
	private Timestamp LastUpdate;
}
