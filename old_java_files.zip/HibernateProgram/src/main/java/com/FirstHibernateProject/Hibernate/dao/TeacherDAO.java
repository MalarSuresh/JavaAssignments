package com.FirstHibernateProject.Hibernate.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.FirstHibernateProject.Hibernate.dto.ActorDTO;
import com.FirstHibernateProject.Hibernate.dto.Teacher;

import jakarta.persistence.TypedQuery;

public class TeacherDAO {
	private static SessionFactory sessionFactory=null;
	
	public TeacherDAO() throws Exception {
		if(sessionFactory == null) {
			ConnectionUtil util=new ConnectionUtil();
			sessionFactory=util.getSessionFactory();
		}
		
	
	}
	
	public void getTeachers() {
 		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx= session.beginTransaction();
		TypedQuery<Teacher> teachers=session.createQuery("from Teacher");
		List<Teacher> TeacherList=teachers.getResultList();
		for(Teacher eachTeacher:TeacherList) {
			System.out.println(eachTeacher);
		}
			tx.commit();
			session.close();
	}
	public static void main(String[] args) {
		try {
			TeacherDAO dao=new TeacherDAO();
			dao.getTeachers();
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
