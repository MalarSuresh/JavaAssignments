package com.FirstHibernateProject.Hibernate.dao;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.FirstHibernateProject.Hibernate.dto.ActorDTO;

import jakarta.persistence.TypedQuery;


public class ActorDAO {
	private static SessionFactory sessionFactory=null;
	
	public ActorDAO() throws Exception {
		if(sessionFactory == null) {
			ConnectionUtil util=new ConnectionUtil();
			sessionFactory=util.getSessionFactory();
		}
		
	
	}
	
	public void getActors() {
 		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx= session.beginTransaction();
		TypedQuery<ActorDTO> actors=session.createQuery("from ActorDTO");
		List<ActorDTO> actorList=actors.getResultList();
		for(ActorDTO eachActor:actorList) {
			System.out.println(eachActor);
		}
			tx.commit();
			session.close();
	}
	public ActorDTO getActor(int actorId) {
 		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx= session.beginTransaction();
		TypedQuery<ActorDTO> query=session.createQuery("from ActorDTO as A where A.actorId = : actorId");
		query.setParameter("actorId", actorId);
		ActorDTO actor=query.getSingleResult();
		System.out.println(actor);
			tx.commit();
			session.close();
			return actor;
	}
	
	public void createActor(String firstName,String lastName) {
 		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx= session.beginTransaction();
		ActorDTO insertActor=new ActorDTO();
		insertActor.setFirstName(firstName);
		insertActor.setLastName(lastName);
		insertActor.setLastUpdate(new Timestamp(System.currentTimeMillis()));
		session.persist(insertActor);//save or saveOrUpdate for earlier version
			tx.commit();
			session.close();
	}
	
	public void updateActor(ActorDTO actor) {
 		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx= session.beginTransaction();
		
		ActorDTO updateActor=session.merge(actor);//update or saveOrUpdate for earlier version
		System.out.println(updateActor);	
		tx.commit();
			session.close();
	}
	public void deleteActor(ActorDTO actor) {
 		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx= session.beginTransaction();
		
		session.remove(actor);//delete for earlier version
		System.out.println("Actor Info removed from DB");	
		tx.commit();
			session.close();
	}
	
	
	public static void main(String[] args) {
		try {
			ActorDAO dao=new ActorDAO();
			//dao.getActor(100);
			//dao.createActor("Kum", "Sure");
			//dao.getActors();
			
			ActorDTO insertActor=new ActorDTO();
			insertActor.setActorId(201);
			insertActor.setFirstName("KUMAR");
			insertActor.setLastName("SURESH");
			insertActor.setLastUpdate(new Timestamp(System.currentTimeMillis()));
			//dao.updateActor(insertActor);
			dao.deleteActor(insertActor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
