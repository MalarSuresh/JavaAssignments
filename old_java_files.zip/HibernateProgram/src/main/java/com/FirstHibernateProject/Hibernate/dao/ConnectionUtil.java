package com.FirstHibernateProject.Hibernate.dao;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class ConnectionUtil {
private static SessionFactory sessionFactory=null;
	
	public ConnectionUtil() throws Exception {
		if(sessionFactory == null) {
			setUp();
		}
		
	}
	
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	private void setUp() throws Exception {
		// A SessionFactory is set up once for an application!
		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure() // configures settings from hibernate.cfg.xml
				.build();
		try {
			sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
		}
		catch (Exception e) {
			StandardServiceRegistryBuilder.destroy( registry );
			e.printStackTrace();
		
		}
	}
}
